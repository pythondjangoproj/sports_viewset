"""Import required module"""
from django.db import models
from IGL_account.models import User
from autoslug import AutoSlugField
from iconApi.settings import default
from iconApi.models import BaseModel
from timezone_field import TimeZoneField
from django_countries.fields import CountryField

from iconApi.mixins import AuditTrailMixin, GuidFieldMixin, ApiMappableMixin, NameDescriptionMixin
from icon.models import Icon


class Platform(BaseModel):
    name = models.CharField(max_length=255)
    manufacturer = models.CharField(max_length=255)

    def get_games(self):
        return Game.objects.filter(platforms=self)

    def __str__(self):
        return self.name


class Game(BaseModel,
           GuidFieldMixin):
    display_name = models.CharField(max_length=255)
    slug = AutoSlugField(populate_from='full_name', unique=True)
    full_name = models.CharField(max_length=255)
    short_name = models.CharField(max_length=50)
    platforms = models.ManyToManyField(Platform)
    display_image = models.ImageField(upload_to='game_logos', blank=True, null=True)

    def get_platforms(self):
        return self.platforms.all()

    def __str__(self):
        return self.display_name


class ParticipantType(BaseModel,
                      NameDescriptionMixin):
    """
    Supported types: single, team.
    """

    def __str__(self):
        return self.name


class TournamentStatus(BaseModel,
                       NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Tournament status options'

    """
    Supported statuses: Pending, Running, Completed
    """

    def __str__(self):
        return self.name


class TournamentFormat(BaseModel,
                       NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Tournament format options'

    def __str__(self):
        return self.name


class Tournament(BaseModel,
                 AuditTrailMixin,
                 GuidFieldMixin):
    name = models.CharField(max_length=150, unique=True)
    full_name = models.CharField(max_length=255)
    slug = AutoSlugField(populate_from='full_name', unique_with='scheduled_date_start')
    game = models.ForeignKey(Game, on_delete=models.SET_NULL, null=True)
    size = models.PositiveSmallIntegerField()

    status = models.ForeignKey(TournamentStatus,
                               on_delete=models.CASCADE,
                               default=default.DEFAULT_TOURNAMENT_STATUS)
    format = models.ForeignKey(TournamentFormat, on_delete=models.SET_NULL, null=True)
    participant_type = models.ForeignKey(ParticipantType,
                                         on_delete=models.CASCADE,
                                         default=default.DEFAULT_PARTICIPANT_TYPE)
    entry_fee = models.PositiveSmallIntegerField(blank=True, null=True)
    country = CountryField(blank=True, null=True)

    scheduled_date_start = models.DateField()
    scheduled_date_end = models.DateField()
    scheduled_start_time = models.TimeField(blank=True, null=True)
    scheduled_timezone = TimeZoneField(blank=True, null=True)

    description = models.TextField(blank=True, null=True)
    rules = models.TextField(blank=True, null=True)

    team_min_size = models.PositiveSmallIntegerField(default=2)
    team_max_size = models.PositiveSmallIntegerField(default=10)

    organizer = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)

    @property
    def registered_participants(self):
        participants = self.participants
        return "{0}/{1}".format(participants.count(), self.size)

    @property
    def participants(self):
        return MatchParticipant.objects.filter(tournament=self)

    @property
    def matches(self):
        return Match.objects.filter(tournament=self)

    @property
    def rounds(self):
        return Round.objects.filter(tournament=self)

    @property
    def prizes(self):
        return Prize.objects.filter(tournament=self)

    def __str__(self):
        return self.name


class StageType(BaseModel):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Stage(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin):
    name = models.CharField(max_length=255)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    number = models.PositiveSmallIntegerField()
    stage_type = models.ForeignKey(StageType, blank=True, null=True, on_delete=models.SET_NULL)
    is_closed = models.BooleanField(default=False)

    def __str__(self):
        return "{0} - Stage {1}".format(self.tournament.name,
                                        self.name)


class Group(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin):
    name = models.CharField(max_length=255)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    stage = models.ForeignKey(Stage, blank=True, null=True, on_delete=models.SET_NULL)
    closed = models.BooleanField(default=False)

    def __str__(self):
        return "{0} - Group {1}".format(
            self.tournament.name,
            self.name,
        )


class Round(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin):
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    stage = models.ForeignKey(Stage, on_delete=models.CASCADE, blank=True, null=True)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, blank=True, null=True)
    number = models.PositiveSmallIntegerField()

    start_datetime = models.DateTimeField(blank=True, null=True)
    end_datetime = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return "{0} - Round {1}".format(
            self.tournament.name,
            self.number
        )


class Match(BaseModel,
            AuditTrailMixin,
            GuidFieldMixin):
    class Meta:
        verbose_name_plural = 'Matches'

    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    round = models.ForeignKey(Round, on_delete=models.CASCADE, blank=True, null=True)
    stage = models.ForeignKey(Stage, on_delete=models.CASCADE, blank=True, null=True)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, blank=True, null=True)

    number = models.PositiveSmallIntegerField()
    scheduled_datetime = models.DateTimeField(blank=True, null=True)
    start_datetime = models.DateTimeField(blank=True, null=True)
    end_datetime = models.DateTimeField(blank=True, null=True)

    @property
    def participants(self):
        return MatchParticipant.objects.filter(match=self)

    def __str__(self):
        return "{0} - Match {1}".format(self.tournament.name,
                                        self.number)


class MatchParticipant(BaseModel,
                       GuidFieldMixin):
    user = models.ForeignKey(default.AUTH_USER_MODEL, on_delete=models.CASCADE)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    match = models.ForeignKey(Match, on_delete=models.CASCADE)

    registered_at = models.DateTimeField(blank=True, null=True)
    checked_in_at = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return self.user.email


class MatchResult(BaseModel,
                  GuidFieldMixin):
    match = models.ForeignKey(Match, on_delete=models.CASCADE)
    evidence = models.ImageField(upload_to="match-evidence", blank=True, null=True)
    submitted_by = models.ForeignKey(MatchParticipant, on_delete=models.SET_NULL, blank=True, null=True)

    def __str__(self):
        return "Result: for {0}, Match {1}".format(self.match.tournament, self.match.number)


class RegistrationStatus(BaseModel,
                         NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Registration status options'

    def __str__(self):
        return self.name


class Registration(BaseModel,
                   GuidFieldMixin):
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    participant = models.ForeignKey(default.AUTH_USER_MODEL, on_delete=models.CASCADE)
    status = models.ForeignKey(RegistrationStatus,
                               default=default.DEFAULT_REGISTRATION_STATUS,
                               on_delete=models.CASCADE)
    created_at = models.DateTimeField()


class Prize(BaseModel,
            NameDescriptionMixin):
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='tournament_prizes', blank=True, null=True)
    prize_place = models.PositiveSmallIntegerField()

    def __str__(self):
        return "{0}".format(self.tournament)


class TrophyCategory(BaseModel,
                     AuditTrailMixin,
                     GuidFieldMixin,
                     ApiMappableMixin):
    """ A class is used to represent the TrophyCategory """
    category_name = models.CharField(max_length=225)
    badges_image = models.ImageField(default='tournament.jpg', upload_to='badges_logos', blank=True, null=True)

    def __str__(self):
        return '%s, %s' % (self.category_name, self.badges_image)


class BadgesCategory(BaseModel,
                     AuditTrailMixin,
                     GuidFieldMixin,
                     ApiMappableMixin):
    """ A class is used to represent the TrophyCategory """
    category_id = models.ManyToManyField(TrophyCategory)
    badge_type = models.CharField(max_length=225)
    display_name = models.CharField(max_length=225)

    def __str__(self):
        return self.display_name


class Challenges(models.Model):
    """ A class is used to represent the TrophyCategory """
    wins20 = models.IntegerField(null=True, blank=True)
    wins50 = models.IntegerField(null=True, blank=True)
    wins100 = models.IntegerField(null=True, blank=True)
    wins20_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)
    wins50_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)
    wins100_image = models.ImageField(upload_to='challenges_logos', blank=True, null=True)


class Tournaments(models.Model):
    """ A class is used to represent the Tournaments """
    wins1 = models.IntegerField(null=True, blank=True)
    wins5 = models.IntegerField(null=True, blank=True)
    wins10 = models.IntegerField(null=True, blank=True)
    wins1_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)
    wins5_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)
    wins10_image = models.ImageField(upload_to='Tournaments_logos', blank=True, null=True)


class EarnedCoins(models.Model):
    """ A class is used to represent the EarnedCoins """
    earn500 = models.IntegerField(null=True, blank=True)
    earn1000 = models.IntegerField(null=True, blank=True)
    earn10000 = models.IntegerField(null=True, blank=True)
    earn500_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)
    earn1000_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)
    earn10000_image = models.ImageField(upload_to='earned_coins_logos', blank=True, null=True)


class Friends(models.Model):
    """ A class is used to represent the Friends """
    add5 = models.IntegerField(null=True, blank=True)
    add10 = models.IntegerField(null=True, blank=True)
    add20 = models.IntegerField(null=True, blank=True)
    add5_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)
    add10_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)
    add20_image = models.ImageField(upload_to='friends_logos', blank=True, null=True)


class LoginStreak(models.Model):
    """ A class is used to represent the LoginStreak """
    log5 = models.IntegerField(null=True, blank=True, default=0)
    log10 = models.IntegerField(null=True, blank=True)
    log20 = models.IntegerField(null=True, blank=True)
    log5_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)
    log10_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)
    log20_image = models.ImageField(upload_to='logic_streak_logos', blank=True, null=True)


class UserBadges(models.Model):
    """ A class is used to represent the UserBadges """

    user_id = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    challenges = models.ForeignKey(Challenges, on_delete=models.CASCADE, blank=True, null=True)
    tournaments = models.ForeignKey(Tournaments, on_delete=models.CASCADE, blank=True, null=True)
    earned_coins = models.ForeignKey(EarnedCoins, on_delete=models.CASCADE, blank=True, null=True)
    Friend = models.ForeignKey(Friends, on_delete=models.CASCADE, blank=True, null=True)
    login_streak = models.ForeignKey(LoginStreak, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return str(self.user_id)
