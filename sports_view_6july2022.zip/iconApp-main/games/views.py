"""Import Required Module"""
from django.shortcuts import render
from rest_framework.response import Response
from IGL_account.models import User
from .serializer import PlatformSerializer, GameSerializer, TournamentSerializer, StageTypeSerializer, StageSerializer, \
    GroupSerializer, RoundSerializer, MatchSerializer, MatchParticipantSerializer, TrophyCategorySerializer, \
    BadgesCategorySerializer, UserBadgesSerializer

from .models import Platform, Game, Tournament, StageType, Stage, Group, Round, Match, MatchParticipant, BadgesCategory, \
    TrophyCategory, UserBadges
from rest_framework import generics
from rest_framework import generics, viewsets, routers
from django_filters import rest_framework as filters
import logging

logger = logging.getLogger(__name__)

# Create your views here.

router = routers.DefaultRouter()


class PlatformViewSet(viewsets.ModelViewSet):
    queryset = Platform.objects.all()
    serializer_class = PlatformSerializer


router.register('platforms', PlatformViewSet)


class GameFilter(filters.FilterSet):
    class Meta:
        model = Game
        fields = [
            'full_name',
            'short_name',
            'platforms'
        ]


class GameViewSet(viewsets.ModelViewSet):
    queryset = Game.objects.all()
    serializer_class = GameSerializer
    filter_backends = [filters.DjangoFilterBackend, ]
    filterset_class = GameFilter


router.register(r'games', GameViewSet)


class TournamentFilter(filters.FilterSet):
    min_entry_fee = filters.NumberFilter(field_name="entry_fee", lookup_expr='gte')
    max_entry_fee = filters.NumberFilter(field_name='entry_fee', lookup_expr='lte')

    class Meta:
        model = Tournament
        fields = [
            'name',
            'full_name',
            'min_entry_fee',
            'max_entry_fee',
            'scheduled_date_start',
        ]


class TournamentViewSet(viewsets.ModelViewSet):
    queryset = Tournament.objects.all()
    serializer_class = TournamentSerializer
    filter_backends = [filters.DjangoFilterBackend, ]
    filterset_class = TournamentFilter


router.register(r'tournaments', TournamentViewSet)


class StageTypeViewSet(viewsets.ModelViewSet):
    queryset = StageType.objects.all()
    serializer_class = StageTypeSerializer


router.register(r'stagetype', StageTypeViewSet)


class StageViewSet(viewsets.ModelViewSet):
    queryset = Stage.objects.all()
    serializer_class = StageSerializer


router.register(r'stage', StageViewSet)


class GroupViewSet(viewsets.ModelViewSet):
    queryset = Group.objects.all()
    serializer_class = GroupSerializer


router.register(r'group', GroupViewSet)


class RoundViewSet(viewsets.ModelViewSet):
    queryset = Round.objects.all()
    serializer_class = RoundSerializer


router.register(r'round', RoundViewSet)


class MatchViewSet(viewsets.ModelViewSet):
    queryset = Match.objects.all()
    serializer_class = MatchSerializer


router.register(r'match', MatchViewSet)


class MatchParticipantViewSet(viewsets.ModelViewSet):
    queryset = MatchParticipant.objects.all()
    serializer_class = MatchParticipantSerializer


router.register(r'matchparticipant', MatchParticipantViewSet)


class TrophyCategoryViewSet(viewsets.ModelViewSet):
    queryset = TrophyCategory.objects.all()
    serializer_class = TrophyCategorySerializer


router.register(r'trophycategory', TrophyCategoryViewSet)


class BadgesCategoryViewSet(viewsets.ModelViewSet):
    queryset = BadgesCategory.objects.all()
    serializer_class = BadgesCategorySerializer


router.register(r'badgescategory', BadgesCategoryViewSet)


class UserBadgesViewSet(viewsets.ModelViewSet):
    queryset = UserBadges.objects.all()
    serializer_class = UserBadgesSerializer


router.register(r'userbadges', UserBadgesViewSet)


