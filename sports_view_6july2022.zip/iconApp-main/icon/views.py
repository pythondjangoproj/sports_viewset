"""import required module"""
from django.shortcuts import render
from rest_framework.response import Response
from IGL_account.models import User
from .serializer import IconSerializer, IconTeamSerializer, IconTeamMemberSerializer
from rest_framework import generics
from .models import Icon, IconTeam, IconTeamMember
from rest_framework import viewsets, routers
import logging

logger = logging.getLogger(__name__)


class IconViewSet(viewsets.ModelViewSet):
    queryset = Icon.objects.all()
    serializer_class = IconSerializer


class IconTeamViewSet(viewsets.ModelViewSet):
    queryset = IconTeam.objects.all()
    serializer_class = IconTeamSerializer


class IconTeamMemberViewSet(viewsets.ModelViewSet):
    queryset = IconTeamMember.objects.all()
    serializer_class = IconTeamMemberSerializer


router = routers.DefaultRouter()
router.register('icons', IconViewSet)
router.register('icon-teams', IconTeamViewSet)
router.register('icon-team-members', IconTeamMemberViewSet)
