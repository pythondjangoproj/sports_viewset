"""import required module"""
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from IGL_account.renderers import UserRenderer
from rest_framework import generics
from IGL_account.serializer import UserRegistrationSerializer, UserLoginSerializer, UserProfileSerializer, \
    UserChangePasswordSerializer, SendPasswordResetEmailSerializer, UserPasswordResetSerializer, \
    Igl_Username_Serializer, \
    UpdateUserProfileSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from IGL_account.models import User
import logging
import hashlib
from iconApi.settings.default import base_url
from datetime import date
from django.db.models import F
from games.models import LoginStreak, UserBadges
from django.utils.encoding import smart_str, force_bytes, DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from IGL_account.utils import Util

from iconApi.settings import default

logger = logging.getLogger(__name__)


def get_tokens_for_user(user):
    """Generate Token Manually"""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserRegistrationView(APIView):
    """To perform the IGL user registration"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            serializer = UserRegistrationSerializer(data=request.data)
            if serializer.is_valid(raise_exception=True):
                user = serializer.save()
                token = get_tokens_for_user(user)
                return Response({'token': token, 'msg': 'Registration Successful'}, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Email is already registered"})


# class UserLoginView(APIView):
#     """to perform login operation for registered IGL user"""
#
#     renderer_classes = [UserRenderer]
#
#     def post(self, request, format=None):
#         try:
#             serializer = UserLoginSerializer(data=request.data)
#             if serializer.is_valid(raise_exception=True):
#                 email = serializer.data.get('email')
#                 password = serializer.data.get('password')
#                 user = authenticate(email=email, password=password)
#                 if user is not None:
#                     token = get_tokens_for_user(user)
#                     return Response({'token': token, 'msg': 'Login Success'}, status=status.HTTP_200_OK)
#                 else:
#                     return Response({'errors': {'non_field_errors': ['Email or Password is not Valid']}},
#                                     status=status.HTTP_404_NOT_FOUND)
#
#             return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#         except Exception as e:
#             logging.info('User Information incoming!', e)
#             return Response({"message": "Unable to perform login operation with given credential"})
#


class UserLoginView(APIView):
    """to perform login operation for registered IGL user"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            serializer = UserLoginSerializer(data=request.data)
            if serializer.is_valid(raise_exception=True):
                email = serializer.data.get('email')
                password = serializer.data.get('password')
                user = authenticate(email=email, password=password)
                last_login_time = User.objects.values("last_login_time").filter(email=email)[0]
                user_details = User.objects.values("id", "count").filter(email=email)[0]
                current_date = date.today()

                if (last_login_time['last_login_time'] == None) or (current_date > last_login_time['last_login_time']):
                    User.objects.filter(email=email).update(count=F('count') + 1)
                    User.objects.filter(email=email).update(last_login_time=current_date)

                login_streak_value = list(
                    UserBadges.objects.values_list('login_streak_id').filter(user_id_id=user_details['id']))

                if user_details['count'] == 5 or user_details['count'] == 10 or user_details['count'] == 20:

                    image_url = "logic_streak_logos/" + f"{user_details['count']}" + "_days.png"
                    column_name = f"log{user_details['count']}"
                    image_column_name = f"log{user_details['count']}_image"

                    if not login_streak_value:
                        LoginStreakQuery = LoginStreak.objects.create(id=user_details['id'],
                                                                      **{column_name: user_details['count']},
                                                                      **{image_column_name: image_url})
                        LoginStreakQuery.save()
                        UserBadgesQueryset = UserBadges.objects.create(login_streak_id=user_details['id'],
                                                                       user_id_id=user_details['id'])
                        UserBadgesQueryset.save()
                    else:
                        LoginStreak.objects.values(column_name).filter(id=user_details['id']).update(
                            **{column_name: user_details['count']}, **{image_column_name: image_url})

                count = User.objects.values("count").filter(email=email)[0]

                if user is not None:
                    token = get_tokens_for_user(user)
                    return Response({'token': token, 'msg': 'Login Success', 'count': count['count']},
                                    status=status.HTTP_200_OK)
                else:
                    return Response({'errors': {'non_field_errors': ['Email or Password is not Valid']}},
                                    status=status.HTTP_404_NOT_FOUND)

            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('User Information incoming!', e)
            return Response({"message": "Unable to perform login operation with given credential"})


class UserProfileView(APIView):
    """To fetch the IGL User details"""
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        try:
            serializer = UserProfileSerializer(request.user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('User profile Information incoming!', e)
            return Response({"message": "Unable to get the user Record"})


class UserChangePasswordView(APIView):
    """TO change the IGL user password"""
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            serializer = UserChangePasswordSerializer(data=request.data, context={'user': request.user})
            if serializer.is_valid(raise_exception=True):
                return Response({'msg': 'Password Changed Successfully'}, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to change user password"})


class SendPasswordResetEmailView(APIView):
    """to send the reset password link on user email id"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            serializer = SendPasswordResetEmailSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            return Response({'msg': 'Password Reset link send. Please check your Email'}, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to send link on registered email id "})


class UserPasswordResetView(APIView):
    """to reset the user password"""
    renderer_classes = [UserRenderer]

    def post(self, request, uid, token, format=None):
        try:
            serializer = UserPasswordResetSerializer(data=request.data, context={'uid': uid, 'token': token})
            serializer.is_valid(raise_exception=True)
            return Response({'msg': 'Password Reset Successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('user password Information incoming!', e)
            return Response({"message": "Unable to perform user reset password"})


class IGLUsernameAPI(generics.GenericAPIView):
    """to get the and update the igl username details with default avatar based on ID"""
    serializer_class = Igl_Username_Serializer

    def get(self, request, pk=None):
        user_id = pk
        try:
            if user_id is not None:
                user = User.objects.get(id=user_id)
                serializer = Igl_Username_Serializer(user)
                return Response({"data": serializer.data})
            user = User.objects.all()
            serializer = Igl_Username_Serializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('IGL user Information incoming!', e)
            return Response({"message": "unable to get user details found"})

    def patch(self, request, pk=None):
        user_id = pk
        try:
            if user_id is not None:
                user = User.objects.get(id=user_id)
                user.IGL_Username = request.data['IGL_Username']
                user.profile_image = request.data['profile_image']
                user.save()
                return Response({"message": "Successfully Update"})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to update user details"})


class UpdateUserProfileAPI(generics.GenericAPIView):
    serializer_class = UpdateUserProfileSerializer

    def get(self, request, pk=None):
        user_id = pk
        try:
            if user_id is not None:
                user = User.objects.get(id=user_id)
                serializer = UpdateUserProfileSerializer(user)
                return Response({"data": serializer.data})
            user = User.objects.all()
            serializer = UpdateUserProfileSerializer(user, many=True)
            return Response({"data": serializer.data})
        except:
            logging.info('Information incoming!')
            return Response({"message": "unable to get user details "})

    def patch(self, request, pk=None):
        user_id = pk
        try:
            if user_id is not None:
                user = User.objects.get(id=user_id)
                user.first_name = request.data['first_name']
                user.last_name = request.data['last_name']
                user.mobile_number = request.data['mobile_number']
                user.email = request.data['email']
                user.save()
                return Response({"message": "Successfully Update"})
        except:
            logging.info('Information incoming!')
            return Response({"message": "Unable to update user details"})


class SendInvitationEmailAPI(APIView):

    def post(self, request, format=None):
        if request.user.is_authenticated:
            user = request.user.first_name
            user_id = request.user
            email = request.data.get('email')
            if email == '':
                return Response({'msg': 'please enter valid email'})
            # Verifying email is already registered or not
            if not User.objects.filter(email=email).exists():
                uid = urlsafe_base64_encode(force_bytes(user_id.id))

                token = hashlib.sha256(b'PasswordResetTokenGenerator().make_token(user)')
                hex_dig = token.hexdigest()
                print('user hash password Token', hex_dig)

                link = base_url + 'api/user/register/' + uid + '/' + hex_dig

                # Send EMail
                body = 'Hi,' + '\n\n' + 'IGL user ' + str(
                    user) + ' sent this invitation to you. Please click on below link and register yourself with IGL.' + '\n\n' + link + '\n\n' + 'Thanks,\n\n Team IGL'

                data = {
                    'subject': 'Invitation for you !!',
                    'body': body,
                    'to_email': email
                }
                Util.send_email(data)
                return Response({'msg': ' Invitation email send successfully', 'Link': link})
            else:
                return Response({"msg": "Email registered already"})
        else:
            return Response({'msg': 'You are not a Registered User'})
