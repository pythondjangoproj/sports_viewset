from django.urls import path
from profile_app.views import UserPlatformAPI, UserGameAPI, UserMatchParticipantAPI, \
    GetUserSubmitAPI, \
    IGLNotificationAPI, GlobalIndexHierarchyAPI, GlobalIndexAPI, PGIUserSubmitAPI, UserIglNotificationViewAPI, \
    UserTrophyCaseAPI, CompleteProfileAPI, CompleteProfileUpdateAPI
from . import views
urlpatterns = [
    path('userplatform/<int:pk>/', UserPlatformAPI.as_view(), name='userplatform'),
    path('userplatform/', UserPlatformAPI.as_view(), name='userplatform'),
    path('userplatform/<int:pk>/', UserPlatformAPI.as_view(), name='userplatform'),
    path('usergame/<int:pk>/', UserGameAPI.as_view(), name='usergame'),
    path('usergame/', UserGameAPI.as_view(), name='usergame'),
    path('usermatchparticipants/', UserMatchParticipantAPI.as_view(), name='usermatchparticipants'),
    path('usertrophycase/', UserTrophyCaseAPI.as_view(), name='usercasetrophy'),
    path('usertrophycase/<int:pk>/', UserTrophyCaseAPI.as_view(), name='usercasetrophy'),
    path('usersubmitdetails/', GetUserSubmitAPI.as_view(), name='usersubmitdetails'),
    path('usersubmitdetails/<int:pk>/', GetUserSubmitAPI.as_view(), name='usersubmitdetails'),
    path('igl_notification/', IGLNotificationAPI.as_view(), name='igl_notification'),
    path('igl_notification/<int:pk>/', IGLNotificationAPI.as_view(), name='igl_notification'),
    path('user_igl_notification/', UserIglNotificationViewAPI.as_view(), name='user_igl_notification'),
    path('user_igl_notification/<int:pk>/', UserIglNotificationViewAPI.as_view(), name='user_igl_notification'),
    path('globalindexHierachy/', GlobalIndexHierarchyAPI.as_view(), name='globalindex'),
    path('globalindex/', GlobalIndexAPI.as_view(), name='globalindex'),
    path('globalindex/<int:pk>/', GlobalIndexAPI.as_view(), name='globalindex'),
    path('usersubmit/', PGIUserSubmitAPI.as_view(), name='usersubmit'),
    path('usersubmit/<int:pk>/', PGIUserSubmitAPI.as_view(), name='usersubmit'),
    path('completeprofile/', CompleteProfileAPI.as_view(), name='completeprofile'),
    path('completeprofile/<int:pk>/', CompleteProfileAPI.as_view(), name='completeprofile'),
    path('send_friend_request/', views.get, name='send_friend_request'),
    path('add_remove_friend_request/', views.add_or_remove_friend, name='add_or_remove_friend'),
    path('update_complete_profile/', CompleteProfileUpdateAPI.as_view(), name='update_complete_profile'),
    path('update_complete_profile/<int:pk>/', CompleteProfileUpdateAPI.as_view(), name='update_complete_profile'),

]

