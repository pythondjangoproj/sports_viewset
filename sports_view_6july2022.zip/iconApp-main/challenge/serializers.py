from .models import Challenge, ChallengeOutcome, DirectChallenge, OpenChallenge, CreateChallenge
from rest_framework import serializers
from django_filters import rest_framework as filters
from games.serializer import GameSerializer


class ChallengeFilter(filters.FilterSet):
    min_entry_fee = filters.NumberFilter(field_name="entry_fee", lookup_expr='gte')
    max_entry_fee = filters.NumberFilter(field_name='entry_fee', lookup_expr='lte')

    class Meta:
        model = Challenge
        fields = [
            'id',
            'guid',
            'entry_fee',
            'game',
            'platforms',
            'is_open',
            'min_entry_fee',
            'max_entry_fee'
        ]


class ChallengeSerializer(serializers.ModelSerializer):
    outcome = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Challenge
        fields = [
            'id',
            'guid',
            'status',
            'challenger',
            'recipient',
            'entry_fee',
            'game',
            'platforms',
            'is_open',
            'sent_at',
            'responded_at',
            'canceled_at',
            'outcome',
            'created_by',
        ]


class ChallengeOutcomeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChallengeOutcome
        fields = [
            'id',
            'guid',
            'challenge',
            'winner',
            'submitted_at',
            'total_winnings',
        ]


class ChallengeResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Challenge
        fields = [
            'id',
            'responded_at',
            'status',
        ]


class DirectChallengeSerializer(serializers.ModelSerializer):
    class Meta:
        model = DirectChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'Opponent',
            'entry_fee',
            'game_mode',
        ]


class OpenChallengeSerializer(serializers.ModelSerializer):
    platforms = serializers.StringRelatedField(many=True)
    game = GameSerializer()
    opponent = serializers.StringRelatedField()
    game_mode = serializers.StringRelatedField()

    class Meta:
        model = OpenChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'opponent',
            'entry_fee',
            'game_mode',
        ]


class CreateOpenChallengeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OpenChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'opponent',
            'entry_fee',
            'game_mode',
        ]


class CreateNewChallengeSerializer(serializers.ModelSerializer):
    platforms = serializers.StringRelatedField(many=True)
    game = GameSerializer()
    status = serializers.StringRelatedField()
    Opponent = serializers.StringRelatedField()
    game_mode = serializers.StringRelatedField()

    class Meta:
        model = CreateChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'status',
            'entry_fee',
            'Opponent',
            'game_mode',
        ]


class CreatingNewChallengeSerializer(serializers.ModelSerializer):
    class Meta:
        model = CreateChallenge
        fields = [
            'id',
            'platforms',
            'game',
            'status',
            'entry_fee',
            'Opponent',
            'game_mode',
        ]
