from django.shortcuts import render
from .models import Challenge, ChallengeOutcome, DirectChallenge, OpenChallenge, CreateChallenge, ChallengeStatus
from .serializers import ChallengeSerializer, ChallengeOutcomeSerializer, \
    DirectChallengeSerializer, \
    OpenChallengeSerializer, CreateOpenChallengeSerializer, CreateNewChallengeSerializer, \
    CreatingNewChallengeSerializer, \
    ChallengeResponseSerializer
import ledgerclient
from ledgerclient.api import transactions_api, accounts_api
from ledgerclient.model.error_response import ErrorResponse
from ledgerclient.model.transaction_data import TransactionData
from ledgerclient.model.posting import Posting
from ledgerclient.model.create_transaction_response import CreateTransactionResponse
from django_filters import rest_framework as filters
from django.utils import timezone
from iconApi.settings import default
from rest_framework.response import Response
from rest_framework import generics
from rest_framework.decorators import action
from rest_framework import status, permissions, viewsets, serializers, routers
from pprint import pprint
from iconApi.settings import default
from .serializers import ChallengeFilter


# # Create your views here.

# ledger_config = ledgerclient.Configuration(
#     host=default.LEDGER_URL,
#     username=default.LEDGER_USERNAME,
#     password=default.LEDGER_PASSWORD,
#     discard_unknown_keys=True,
# )


class IsChallengeRecipient(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        # User must be the recipient of the challenge in order to accept or refuse it
        return obj.recipient == request.user


class IsChallengeCreator(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        # The User must be the creator of the challenge in order to cancel
        return obj.challenger == request.user


class ChallengeViewSet(viewsets.ModelViewSet):
    queryset = Challenge.objects.all()
    serializer_class = ChallengeSerializer
    filter_backends = [filters.DjangoFilterBackend, ]
    filterset_class = ChallengeFilter

    def create(self, request, *args, **kwargs):

        with ledgerclient.ApiClient(ledger_config) as api_client:
            account_api = accounts_api.AccountsApi(api_client)
            ledger = default.LEDGER_NAME
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                try:
                    '''
                    Confirm user has sufficient ICOIN to cover their entry fee
                    '''
                    wallet = request.user.ledger_account_id
                    resp = account_api.get_account(ledger, wallet)
                    current_balance = resp.data.balances[default.LEDGER_ASSET_NAME]
                    if current_balance < serializer.validated_data['entry_fee']:
                        raise serializers.ValidationError("insufficient_funds")

                    instance = serializer.save()
                    headers = self.get_success_headers(serializer.data)
                    api_instance = transactions_api.TransactionsApi(api_client)
                    '''
                    Execute transaction moving entry fee funds from user account 
                    to inflight address for this challenge
                    '''
                    event_ref = "{0}::CREATE".format(instance.ledger_id)
                    t = TransactionData(
                        metadata={"type": "entry_fee",
                                  "challenge_id": instance.guid.hex
                                  },
                        postings=[
                            Posting(
                                amount=instance.entry_fee,
                                asset=default.LEDGER_ASSET_NAME,
                                destination=instance.inflight_address_ch,
                                source=instance.challenger_address
                            ),
                        ],
                        reference=event_ref,
                    )
                    try:
                        api_response = api_instance.create_transaction(default.LEDGER_NAME, t)
                        pprint(api_response)
                    except ledgerclient.ApiException as e:
                        print("Exception when calling TransactionsApi->create_transaction: %s\n" % e)
                        return Response(serializer.errors,
                                        status=status.HTTP_400_BAD_REQUEST)
                except ledgerclient.ApiException as e:
                    print("Exception when calling AccountsApi->get_account: %s\n" % e)
            else:
                print(serializer.errors)
                headers = self.get_success_headers(serializer)
                return Response(serializer.data, status=status.HTTP_400_BAD_REQUEST, headers=headers)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    @action(detail=True, methods=['post'], permission_classes=[IsChallengeRecipient])
    def accept(self, request, pk=None):
        challenge = self.get_object()
        accept_status = ChallengeStatus.objects.get(id=default.CHALLENGE_ACCEPTED_STATUS)
        if not challenge.responded_at:
            serializer = ChallengeResponseSerializer(data=request.data)
            if serializer.is_valid():
                challenge.status = accept_status
                challenge.responded_at = timezone.now()
                challenge.save()
                with ledgerclient.ApiClient(ledger_config) as api_client:
                    api_instance = transactions_api.TransactionsApi(api_client)
                    '''
                    Execute transaction moving entry fee funds from opponent account 
                    to inflight address for this challenge
                    '''
                    event_ref = "{0}::ACCEPT".format(challenge.ledger_id)
                    t = TransactionData(
                        metadata={"type": "entry_fee",
                                  "challenge_id": challenge.guid.hex
                                  },
                        postings=[
                            Posting(
                                amount=challenge.entry_fee,
                                asset=default.LEDGER_ASSET_NAME,
                                destination=challenge.inflight_address_op,
                                source=challenge.recipient_address
                            ),
                        ],
                        reference=event_ref,
                    )
                    try:
                        api_response = api_instance.create_transaction(default.LEDGER_NAME, t)
                        pprint(api_response)
                    except ledgerclient.ApiException as e:
                        print("Exception when calling TransactionsApi->create_transaction: %s\n" % e)

                return Response({'status': 'challenge_accepted'})

        return Response(serializer.errors,
                        status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'], permission_classes=[IsChallengeRecipient])
    def refuse(self, request, pk=None):
        refuse_status = ChallengeStatus.objects.get(id=default.CHALLENGE_REFUSED_STATUS)
        challenge = self.get_object()
        if not challenge.responded_at:
            serializer = ChallengeResponseSerializer(data=request.data)
            if serializer.is_valid():
                challenge.status = refuse_status
                challenge.responded_at = timezone.now()
                challenge.save()
                with ledgerclient.ApiClient(ledger_config) as api_client:
                    api_instance = transactions_api.TransactionsApi(api_client)
                    '''
                    Execute transaction refunding entry fee funds from challenger inflight account
                    back to challenger wallet if opponent refuses the 1v1 direct challenge.
                    '''
                    event_ref = "{0}::REFUSE".format(challenge.ledger_id)
                    t = TransactionData(
                        metadata={"type": "entry_fee_refund",
                                  "challenge_id": challenge.guid.hex
                                  },
                        postings=[
                            Posting(
                                amount=challenge.entry_fee,
                                asset=default.LEDGER_ASSET_NAME,
                                destination=challenge.challenger_address,
                                source=challenge.inflight_address_ch
                            ),
                        ],
                        reference=event_ref,
                    )
                    try:
                        api_response = api_instance.create_transaction(default.LEDGER_NAME, t)
                        pprint(api_response)
                    except ledgerclient.ApiException as e:
                        print("Exception when calling TransactionsApi->create_transaction: %s\n" % e)
                return Response({'status': 'challenge_refused'})
        return Response(serializer.errors,
                        status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'], permission_classes=[IsChallengeCreator])
    def cancel(self, request, pk=None):
        cancel_status = ChallengeStatus.objects.get(id=default.CHALLENGE_CANCELED_STATUS)
        challenge = self.get_object()
        if not challenge.responded_at:
            serializer = ChallengeResponseSerializer(data=request.data)
            if serializer.is_valid():
                challenge.responded_at = timezone.now()
                challenge.status = cancel_status
                challenge.save()
                with ledgerclient.ApiClient(ledger_config) as api_client:
                    api_instance = transactions_api.TransactionsApi(api_client)
                    '''
                    Execute transaction moving entry fee funds from challenger inflight account 
                    to challenger wallet if the challenge is canceled

                    #TODO: Check if opponent has accepted challenge yet and refund them as well
                    if necessary.
                    '''
                    event_ref = "{0}::CANCEL".format(challenge.ledger_id)
                    t = TransactionData(
                        metadata={"type": "entry_fee_refund",
                                  "challenge_id": challenge.guid.hex
                                  },
                        postings=[
                            Posting(
                                amount=challenge.entry_fee,
                                asset=default.LEDGER_ASSET_NAME,
                                destination=challenge.challenger_address,
                                source=challenge.inflight_address_ch,
                            ),
                        ],
                        reference=event_ref,
                    )
                    try:
                        api_response = api_instance.create_transaction(default.LEDGER_NAME, t)
                        pprint(api_response)
                    except ledgerclient.ApiException as e:
                        print("Exception when calling TransactionsApi->create_transaction: %s\n" % e)
                return Response({'status': 'challenge_canceled'})
        return Response(serializer.errors,
                        status=status.HTTP_400_BAD_REQUEST)


class ChallengeOutcomeViewSet(viewsets.ModelViewSet):
    queryset = ChallengeOutcome.objects.all()
    serializer_class = ChallengeOutcomeSerializer


router = routers.DefaultRouter()
router.register(r'challenges', ChallengeViewSet)
router.register(r'outcomes', ChallengeOutcomeViewSet)


class DirectChallengeViewSet(viewsets.ModelViewSet):
    queryset = DirectChallenge.objects.all()
    serializer_class = DirectChallengeSerializer


router.register(r'directchallenge', DirectChallengeViewSet)


class OpenChallengeAPI(generics.GenericAPIView):
    serializer_class = CreateOpenChallengeSerializer

    def post(self, request):
        """Create List of record for open challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreateOpenChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the open challenge"})

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = OpenChallenge.objects.get(id=user_id)
                serializer = OpenChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = OpenChallenge.objects.all()
            serializer = OpenChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of open challenge"})


class CreateNewChallengeAPI(generics.GenericAPIView):
    serializer_class = CreatingNewChallengeSerializer

    def post(self, request):
        """Create List of record for challenge
                    :parm request:object to pass to state when request page/url requested the user
                     """
        try:
            serializer = CreatingNewChallengeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('User challenge Information incoming!', e)
            return Response({"message": "Unable to create the new challenge"})

    def get(self, request, pk=None):
        """return a list of all direct challenges result on specific Platform, game
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to challenge id.
            """
        user_id = pk

        try:
            if user_id is not None:
                user = CreateChallenge.objects.get(id=user_id)
                serializer = CreateNewChallengeSerializer(user, many=True)
                return Response({"data": serializer.data})
            user = CreateChallenge.objects.all()
            serializer = CreateNewChallengeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            # logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the details of new created challenge"})
