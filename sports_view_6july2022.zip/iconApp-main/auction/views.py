from django.shortcuts import render
from .models import Auction, Bid, Raffle, RafflePurchase
from .serializers import AuctionSerializer, BidSerializer, RaffleSerializer, RafflePurchaseSerializer
from rest_framework import viewsets


# Create your views here.

class AuctionViewSet(viewsets.ModelViewSet):
    serializer_class = AuctionSerializer
    queryset = Auction.objects.all()


class BidViewSet(viewsets.ModelViewSet):
    serializer_class = BidSerializer
    queryset = Bid.objects.all()


class RaffleViewSet(viewsets.ModelViewSet):
    serializer_class = RaffleSerializer
    queryset = Raffle.objects.all()


class RafflePurchaseViewSet(viewsets.ModelViewSet):
    serializer_class = RafflePurchaseSerializer
    queryset = RafflePurchase.objects.all()
