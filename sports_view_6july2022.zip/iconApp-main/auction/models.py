from django.db import models
# from django.conf import settings
# from django.contrib.auth.models import User
from iconApi.settings import default
from IGL_account.models import User
from iconApi.models import BaseModel
from iconApi.mixins import AuditTrailMixin, GuidFieldMixin, NameDescriptionMixin


class AuctionCategory(BaseModel,
                      NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Auction item categories'

    def __str__(self):
        return "{0}".format(self.name)


class Auction(BaseModel,
              NameDescriptionMixin,
              GuidFieldMixin,
              AuditTrailMixin):
    """
    Name and Description fields for the item being auctioned
    are inherited via NameDescriptionMixin
    """
    category = models.ForeignKey(AuctionCategory, on_delete=models.CASCADE, default=default.AUCTION_DEFAULT_CATEGORY)
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    min_bid = models.PositiveSmallIntegerField(blank=True, null=True)
    display_image = models.ImageField(upload_to='auction_images', blank=True, null=True)

    @property
    def bids(self):
        return Bid.objects.filter(auction=self)

    @property
    def total_bids(self):
        if self.bids:
            return self.bids.count()
        return 0

    @property
    def highest_bid(self):
        if self.bids:
            return self.bids.order_by('-amount').first().amount
        return 0

    def __str__(self):
        return "{0}".format(self.name)


class Bid(BaseModel,
          GuidFieldMixin,
          AuditTrailMixin):
    auction = models.ForeignKey(Auction, on_delete=models.CASCADE)
    amount = models.PositiveSmallIntegerField()
    bidder = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField()

    @property
    def is_highest_bid(self):
        for bid in self.auction.bids.all().order_by('-amount'):
            return True if bid == self else False

    def __str__(self):
        return "{0}: {1}".format(self.auction.name, self.bidder)


class RaffleCategory(BaseModel,
                     NameDescriptionMixin):
    class Meta:
        verbose_name_plural = 'Raffle item categories'

    def __str__(self):
        return "{0}".format(self.name)


class Raffle(BaseModel,
             NameDescriptionMixin,
             GuidFieldMixin,
             AuditTrailMixin):
    category = models.ForeignKey(RaffleCategory, on_delete=models.CASCADE, default=default.RAFFLE_DEFAULT_CATEGORY)
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    ticket_price = models.PositiveSmallIntegerField()
    display_image = models.ImageField(upload_to='raffle_images', blank=True, null=True)

    @property
    def total_purchases(self):
        return RafflePurchase.objects.filter(raffle=self).count()

    def __str__(self):
        return "{0}".format(self.name)


class RafflePurchase(BaseModel,
                     GuidFieldMixin,
                     AuditTrailMixin):
    raffle = models.ForeignKey(Raffle, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    quantity = models.PositiveSmallIntegerField(default=1)
    purchased_at = models.DateTimeField()

    @property
    def total_cost(self):
        return self.raffle.ticket_price * self.quantity

    def __str__(self):
        return "{0} - {1}".format(self.raffle.name, self.user)
