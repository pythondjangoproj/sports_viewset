from .models import Auction, Bid, RaffleCategory, Raffle, RafflePurchase
from rest_framework import serializers


class BidSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bid
        fields = [
            'id',
            'auction',
            'amount',
            'bidder',
            'created_at',
            'is_highest_bid',
        ]


class AuctionSerializer(serializers.ModelSerializer):
    bids = BidSerializer(many=True, read_only=True)

    class Meta:
        model = Auction
        fields = [
            'id',
            'name',
            'description',
            'display_image',
            'starts_at',
            'ends_at',
            'bids',
        ]


class RaffleCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = RaffleCategory
        fields = [
            'id',
            'name',
            'description',
        ]


class RaffleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Raffle
        fields = [
            'id',
            'name',
            'description',
            'category',
            'display_image',
            'starts_at',
            'ends_at',
            'ticket_price',
        ]


class RafflePurchaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = RafflePurchase
        fields = [
            'id',
            'raffle',
            'quantity',
            'total_cost',
            'user',
            'purchased_at',
        ]
